else
----

Starts the else portion of an if block.

.. code-block:: cmake

  else([<condition>])

See the :command:`if` command.
